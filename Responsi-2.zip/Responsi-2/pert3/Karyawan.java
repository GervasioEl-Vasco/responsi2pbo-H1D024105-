class Karyawan {
    // Deklarasikan variabel/state dasar (nama, gajiPokok)
    // Gunakan access modifier yang tepat agar bisa diakses oleh subclass (misal: protected)
    
    
    // Constructor untuk inisialisasi nama dan gajiPokok
    
    
    // Method untuk menampilkan informasi dasar karyawan
    void tampilInfo() {
        
    }
}