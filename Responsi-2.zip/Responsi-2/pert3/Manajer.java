// Gunakan keyword untuk mewarisi class Karyawan
class Manajer ... {
    // Deklarasikan variabel tambahan khusus Manajer (tunjangan)
    
    
    // Constructor
    // Tips: Gunakan 'super' untuk memanggil constructor parent
    
    
    // Method Override tampilInfo
    // Tips: Tampilkan info dasar, lalu tambahkan info tunjangan dan total gaji
    @Override
    void tampilInfo() {
        
    }
}