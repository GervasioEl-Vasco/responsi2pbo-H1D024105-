class Customer {
    // TODO: Buatkan atribut

    // TODO: Sediakan constructor

    void tampilkanInfo() {
        // TODO: tampilkan data customer
    }
}
