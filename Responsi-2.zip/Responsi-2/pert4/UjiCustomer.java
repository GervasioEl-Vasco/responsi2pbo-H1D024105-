public class UjiCustomer {
    public static void main(String[] args) {

        // TODO: Buat object Customer

        // TODO: Buat object Member

        // TODO: Tampilkan judul data pelanggan

        // TODO: Tampilkan info untuk Customer biasa

        // TODO: Tampilkan info untuk pelanggan Member
    }
}
