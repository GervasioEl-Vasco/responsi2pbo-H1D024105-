class Member extends Customer {
    // TODO: Tambahkan atribut tambahan

    // TODO: Buat constructor dengan super

    @Override
    void tampilkanInfo() {
        // TODO: panggil super, lalu tampilkan data tambahan
    }
}
