class defaultMesin {
    // Variabel umum mesin (namaMesin, tenagaHP)

    // Constructor
    defaultMesin(String nama, int hp) {

    }

    void tampilInfo() {
        // Tampilkan info dasar mesin
    }

    double nilaiPerforma() {
        // Hitung performa dasar
        return 0.0;
    }

    String kategoriMesin() {
        // Kategori default
        return "";
    }
}
