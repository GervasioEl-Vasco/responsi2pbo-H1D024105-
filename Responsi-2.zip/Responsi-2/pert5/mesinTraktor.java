class mesinTraktor extends defaultMesin {
    // Variabel khusus mesin traktor (kapasitasTarik)

    // Constructor
    mesinTraktor(String nama, int hp, double tarik) {
        super(nama, hp);
    }

    @Override
    void tampilInfo() {
        // Override info mesin traktor
    }

    @Override
    double nilaiPerforma() {
        // Override performa traktor
    }

    @Override
    String kategoriMesin() {
        // Override kategori traktor
    }

    void suaraMesin() {
        // Suara traktor
    }
}
