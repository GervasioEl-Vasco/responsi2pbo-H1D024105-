class mesinMotor extends defaultMesin {
    // Variabel khusus mesin motor (tipeMotor)

    // Constructor
    mesinMotor(String nama, int hp, String tipe) {
        super(nama, hp);
    }

    @Override
    void tampilInfo() {
        // Override info mesin motor
    }

    @Override
    double nilaiPerforma() {
        // Override performa mesin motor
    }

    @Override
    String kategoriMesin() {
        // Override kategori
    }

    void suaraMesin() {
        // Suara mesin motor
    }
}
