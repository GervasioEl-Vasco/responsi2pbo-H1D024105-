class mesinTraktorListrik extends mesinTraktor {
    // Variabel khusus mesin traktor listrik (kapasitasBaterai)

    // Constructor
    mesinTraktorListrik(String nama, int hp, double tarik, double baterai) {
        super(nama, hp, tarik);
    }

    @Override
    void tampilInfo() {
        // Override info traktor listrik
    }

    @Override
    double nilaiPerforma() {
        // Override performa traktor listrik
    }

    @Override
    String kategoriMesin() {
        // Override kategori listrik
    }

    @Override
    void suaraMesin() {
        // Suara traktor listrik
    }
}
