public class UjiSDM {
    public static void main(String[] args) {
        
        // ==========================================================
        // DATA UJI COBA
        // ==========================================================
        
        // 1. BUAT OBJEK ProgrammerMagang
        // Gunakan constructor dengan data: "Andi", 50000.0, "1234".
        
        
        // 2. PENGUJIAN METODE BERURUTAN
        
        // Panggil method hitungGaji(160).
        
        // Cetak hasil dari method getStatusCuti().
        
        // Panggil login("9999") (Tes PIN salah).
        
        // Panggil login("1234") (Tes PIN benar).
        
        // Cetak hasil dari method getRoleAkses().
        
        // Panggil perpanjangKontrak(6).
        
        // Panggil logout().
    }
}